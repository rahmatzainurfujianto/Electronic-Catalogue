import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Electronic } from '../../model/electronic';
import { ElectronicProvider } from '../../providers/electronic/electronic';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  splash = true;
  tabBarElement: any;
  
  electronicList : Electronic[] = [];
  categorySelected = "1";

  constructor(public navCtrl: NavController, public electronicProvider: ElectronicProvider) {
    this.tabBarElement = document.querySelector('.tabbar');
  }
  ionViewDidLoad() {
    this.tabBarElement.style.display = 'none';
    setTimeout(() => {
      this.splash = false;
      this.tabBarElement.style.display = 'flex';
    }, 4000);
  }
  
  ngeOnInit() {
    this.loadElectronic();
  }
  loadElectronic() {
    this.electronicList = [];
    this.electronicProvider.loadElectronic(this.categorySelected)
      .subscribe((result) => {
        console.log(result);
        this.electronicList = result;
  });
  }
}
