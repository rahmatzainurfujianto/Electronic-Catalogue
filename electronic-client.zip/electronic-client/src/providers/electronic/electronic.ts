import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs';
import { Electronic } from '../../model/electronic';

/*
  Generated class for the ElectronicProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class ElectronicProvider {
  private electronicList: Electronic[] = [];
  constructor(public http: Http) {
    console.log('Hello ElectronicProvider Provider');
  }

  loadElectronic(cat_id: string) {
    return this.http.get("http://localhost:8081/api/category/" + cat_id + "/electronic")
      .map((response: Response) => {
        let data = response.json();
        for (let elem of data) {
          elem.images = elem.images.split(",");
        }
        this.electronicList = data;
        return data;
        },
        (error) => console.log(error)
      );
    }
  }

