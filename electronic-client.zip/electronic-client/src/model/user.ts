export class User {
    constructor(
        public userid: string = "",
        public useremail: string = "",
        public userpassword: string = "",
        public name: string = "") {}
}