//express
var express = require('express');
var app = express();

//parser
var bodyParser = require('body-parser');
var urlencodedParser = bodyParser.urlencoded({ extended: false });
var jsonParser = bodyParser.json();

//path
var path = require('path');

//cors
var cors = require("cors")
var cor = cors();
app.use(cor);

//define path
app.use(express.static(path.join(__dirname, "../public")));

//define model
var electronic = require('../model/electronic.js');
var user = require('../model/user');

//define routing or link api
app.get('/api/category/:catid/electronic', function (req, res) {
    var catid = req.params.catid;
    electronic.getElectronicByCat(catid, function (err, result) {
        if (!err) {
            res.send(result);
        }
        else {
        console.log(err);
        res.status(500).send(err);
        }
    });
});

app.get('/api/user', function (req, res) {
    user.getUsers(function(err, result){
        if (!err) {
            res.send(result);
        }
        else {
        console.log(err);
        res.status(500).send(err);
        }
    });
});
/* end routing GET gerUser */

app.post('/api/user', urlencodedParser, jsonParser, function (req, res) {
    var useremail = req.body.useremail;
    var userpassword = req.body.userpassword;
    var name = req.body.name;

    user.addUser(useremail, userpassword, name, function (err, result) {
        if (!err) {
            console.log(result);
            res.send(result.affectedRows + ' record ditambahkan');
        }
        else {
            console.log(err);
            res.status(500).send(err, code);
        }
        });
    });
/* end routing POST addUser */

app.delete('/api/user/:userid', function (req, res) {
    var userid = req.params.userid;

    user.deleteUser(userid, function (err, result) {
       if (!err) {
           console.log(result);
           res.send(result.affectedRows + ' record dihapus');
       } else {
           console.log(err);
           res.status(500).send(err.code);     
       }
    }); 
});
/* end routing POST deleteUser */

app.post('/api/user/:userid', urlencodedParser, jsonParser, function (req, res) {
    var userpassword = req.body.userpassword;
    var name = req.body.name;
    var userid = req.params.userid;

    user.updateUser(userpassword, name, userid, function (err, result) {
        if (!err) {
            console.log(result);
            res.send(result.affectedRows + ' record diubah');  
        } else {
            console.log(err);
            res.status(500).send(err.code);
        }
    });
});
/* end routing POST updateUser */
module.exports = app