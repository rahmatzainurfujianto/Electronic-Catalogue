var mysql = require('mysql');
var dbconnect = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "tugasbesar070"
});

module.exports = dbconnect